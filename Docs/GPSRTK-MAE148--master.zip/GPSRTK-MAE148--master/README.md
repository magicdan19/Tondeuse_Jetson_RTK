# GPSRTK-MAE148-
It is donkey car with gps-RTK which can following pathes within 10cm (also implemented descent algorithm)
